import { Box, Flex, Text } from "@chakra-ui/react";
import Head from "next/head";
import React from "react";
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";
import img from "../../assets/images/about.jpeg";
import Image from "next/image";
import { IoIosCalendar } from "react-icons/io";
import { useRouter } from "next/router";

function ArticleDetail() {
  const {
    query: { id },
  } = useRouter();
  //   console.log(id);
  return (
    <Box fontFamily={"Nunito Sans"} position="relative">
      <Head>
        <title>{id}</title>
      </Head>
      <Navbar
        position="relative"
        bg="white"
        color="black"
        top={0}
        article={true}
      />
      <Flex
        direction={"column"}
        bg="gray.200"
        fontFamily={"Nunito Sans"}
        paddingX={"10%"}
        paddingY={"1%"}
        // alignItems="center"
      >
        <Box
          width={"100%"}
          height={"30rem"}
          position="relative"
          margin={2}
          style={{ borderRadius: "20px" }}
          //   bg="white"
        >
          <Image
            src={img}
            alt="img"
            layout="fill"
            objectFit="contain"
            style={{ borderRadius: "20px" }}
          />
        </Box>
        <Flex
          direction={"column"}
          bg="white"
          flexGrow={1}
          borderRadius={"20px"}
          padding="2%"
          gap={5}
        >
          <Flex gap={2} justifyContent="center">
            <IoIosCalendar size={20} color="#478ac9" />
            <Text color={"gray.500"}>{new Date().toDateString()}</Text>
          </Flex>
          <Text fontWeight={700} fontSize={40} textAlign="center">
            Laboris anim esse non irure anim esse sint in Lorem.
          </Text>
          <Text
            tabIndex={50}
            style={{ textIndent: "50px" }}
            textAlign={"justify"}
          >
            Amet elit labore consequat dolore sunt labore incididunt non sint eu
            culpa. Proident ex laboris eu cillum incididunt exercitation ex.
            Exercitation ut duis occaecat veniam proident laboris fugiat
            pariatur amet. Ea aute proident irure aliqua ut commodo deserunt ea.
            Do aliquip officia nisi officia laborum labore duis. Id nisi aliquip
            quis sunt ad consectetur amet ipsum excepteur incididunt ipsum elit
            ipsum proident. Reprehenderit sunt aliqua aliqua qui esse nisi
            commodo aliqua culpa. Est occaecat officia culpa laborum pariatur
            nulla duis minim et mollit proident. Dolore anim tempor ullamco
            magna et aliqua magna laborum nostrud proident dolor. Deserunt
            voluptate pariatur duis mollit ut aliqua non qui est esse.
            Reprehenderit aliquip proident est laborum sit consectetur Lorem
            veniam pariatur adipisicing Lorem. Anim esse nulla quis excepteur
            consequat sunt ut exercitation. Labore eu ipsum sit sint tempor
            occaecat anim qui. Excepteur nulla qui labore anim consequat cillum
            et voluptate dolore ea quis mollit incididunt. Tempor cupidatat
            cupidatat aliquip culpa occaecat quis tempor quis id. Enim aliqua
            adipisicing et quis reprehenderit elit. Amet et veniam ut
            consectetur cillum eiusmod mollit ex consequat exercitation. Id
            tempor amet qui dolore occaecat occaecat pariatur sunt voluptate qui
            anim irure veniam aliqua. Lorem proident nisi exercitation aliqua
            ea. Cillum consequat ullamco excepteur amet laborum officia anim
            dolore. Aliqua velit incididunt id do sit excepteur consequat
            commodo enim do non. Minim tempor commodo voluptate aliqua aliqua
            exercitation id ipsum dolor ut. Minim ex duis amet labore eiusmod
            sunt quis. Incididunt proident pariatur quis dolore dolore fugiat
            deserunt minim est tempor exercitation aute. Consectetur quis
            deserunt ullamco amet cillum duis officia nostrud tempor tempor
            adipisicing.
          </Text>
        </Flex>
      </Flex>
      <Footer />
    </Box>
  );
}

export default ArticleDetail;
