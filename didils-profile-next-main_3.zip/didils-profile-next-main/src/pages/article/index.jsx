import { Flex } from "@chakra-ui/react";
import React from "react";
import Cardname from "../../components/cardname";
import Layout from "../../components/Layout";
import fadil from "../../assets/images/3.jpeg";
import MiniArticle from "../../components/miniArticle";
function Article() {
  return (
    <Layout title="Artikel | Didil's Group" heroText="Didil's Artikel">
      <Flex
        direction={"column"}
        paddingX={"10%"}
        paddingY={"2%"}
        bg={"rgba(233, 232, 233, 0.8)"}
      >
        <Flex direction={"column"} gap={"5"}>
          <MiniArticle
            title={"Ullamco in aute mollit cillum velit esse magna esse."}
            imageSrc={fadil}
          />
          <MiniArticle
            title={"Eiusmod laborum aute cillum culpa culpa."}
            imageSrc={fadil}
          />
          <MiniArticle
            title={
              "Sint ex qui dolore commodo veniam Lorem veniam occaecat in minim labore pariatur ea."
            }
            imageSrc={fadil}
          />
          <MiniArticle
            title={"Eu consectetur cillum et officia exercitation do deserunt."}
            imageSrc={fadil}
          />
          <MiniArticle
            title={"Ad culpa occaecat velit commodo duis culpa."}
            imageSrc={fadil}
          />
        </Flex>
      </Flex>
    </Layout>
  );
}

export default Article;
