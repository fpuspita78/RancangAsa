/* eslint-disable react/no-unescaped-entities */
/* eslint-disable react-hooks/rules-of-hooks */
import {
  Box,
  Button,
  Container,
  Flex,
  Stack,
  Text,
  useBreakpointValue,
  VStack,
} from "@chakra-ui/react";
import Head from "next/head";
import Image from "next/image";
import React, { useEffect } from "react";
import Footer from "./Footer";
import Navbar from "./Navbar";
import hero from "../assets/images/herolanding.jpg";
import Logo from "../../public/logo.png";
import styles from "../styles/layout.module.css";
import { ImWhatsapp } from "react-icons/im";
import AOS from "aos";
import { Router, useRouter } from "next/router";
import trixie from "../assets/trixie/trixie1.png";

function Layout({
  children,
  title = "Didil's Group",
  heroText = "Didil's Group",
}) {
  const router = useRouter();
  useEffect(() => {
    AOS.init({
      delay: 50,
      duration: 1500,
    });
  });
  return (
    <Box fontFamily={"Nunito Sans"} position="relative">
      <Head>
        <title>{title}</title>
      </Head>
      <Navbar />
      <Flex
        w={"full"}
        h={"100vh"}
        backgroundImage={`url(${hero.src})`}
        backgroundSize={"cover"}
        backgroundPosition={"center center"}
        // bgColor="rgba(1,1,1,1)"
      >
        <VStack
          w={"full"}
          justify={"center"}
          px={useBreakpointValue({ base: 4, md: 8 })}
          zIndex="100"
          bgGradient={"linear(to-r, blackAlpha.900, transparent)"}
        >
          {title === "Sorry we can't found you anything :(" ? (
            <Container>
              <Text
                fontFamily={"Nunito Sans"}
                color={"white"}
                fontWeight={900}
                lineHeight={1.2}
                fontSize={useBreakpointValue({ base: 70, md: 90 })}
              >
                Sorry
              </Text>
              <Text
                fontFamily={"Nunito Sans"}
                color={"white"}
                fontWeight={700}
                lineHeight={1.2}
                fontSize={useBreakpointValue({ base: "2xl", md: 50 })}
              >
                The page you are looking for can't be found
              </Text>
            </Container>
          ) : (
            <>
              <Box
                style={{
                  // position: "absolute",
                  borderStyle: "solid",
                  borderWidth: 3,
                  borderColor: "#478ac9",
                  backgroundColor: "#fff",
                  width: "250px",
                  height: "250px",
                  borderRadius: "250px",
                }}
                data-aos="zoom-in"
              >
                <Image src={Logo} width={300} height={300} alt="logo" />
              </Box>
              <Stack
                maxW={"2xl"}
                align={"center"}
                spacing={6}
                data-aos="zoom-in"
              >
                <Text
                  fontFamily={"Oswald"}
                  color={"white"}
                  fontWeight={700}
                  lineHeight={1.2}
                  fontSize={useBreakpointValue({ base: "3xl", md: 72 })}
                  textAlign="center"
                >
                  {/* eslint-disable-next-line react/no-unescaped-entities */}
                  {heroText}
                </Text>
                <Text
                  fontFamily={"Nunito Sans"}
                  color={"white"}
                  fontWeight={700}
                  lineHeight={1.2}
                  fontSize={useBreakpointValue({ base: "2xl", md: 16 })}
                >
                  {/* eslint-disable-next-line react/no-unescaped-entities */}
                  #ASALMAUBELAJAR
                </Text>
                {title === "Didil's Group" ? (
                  <Stack direction={"row"}>
                    <Button
                      bg={"blue.400"}
                      rounded={"full"}
                      color={"white"}
                      _hover={{ bg: "blue.500" }}
                      onClick={() => router.push("/#profil")}
                    >
                      Show me more
                    </Button>
                    <Button
                      bg={"whiteAlpha.300"}
                      rounded={"full"}
                      color={"white"}
                      _hover={{ bg: "whiteAlpha.500" }}
                      onClick={() => router.push("/contact")}
                    >
                      Contact Us
                    </Button>
                  </Stack>
                ) : (
                  <></>
                )}
              </Stack>
            </>
          )}
        </VStack>
      </Flex>

      {children}
      <Footer />
      <a href="https://wa.link/du9jda" target="_blank" rel="noreferrer">
        <div className={styles.whatsappbtn}>
          <Flex
            justifyContent={"space-around"}
            alignItems="center"
            gap={2}
            position="relative"
            direction={"row-reverse"}
          >
            <Box position={"relative"} width={{ base: "80px", lg: "100px" }}>
              <Image src={trixie} alt="trixie" width={500} height={500} />
              <ImWhatsapp color="#fff" size={40} className={styles.waIcon} />
            </Box>
            <Flex
              direction={"column"}
              color="#fff"
              justifyContent={"space-between"}
              fontSize={20}
              className={styles.whatsapptext}
            >
              <Text fontWeight={700}>Tanya </Text>
              <Text fontWeight={700}>Trixie Yuk!</Text>
            </Flex>
          </Flex>
        </div>
      </a>
    </Box>
  );
}

export default Layout;
