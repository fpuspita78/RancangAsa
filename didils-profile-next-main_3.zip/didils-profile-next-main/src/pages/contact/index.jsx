/* eslint-disable react/no-unescaped-entities */
import { Box, Container, Flex, Text } from "@chakra-ui/react";
import React, { useEffect } from "react";
import Layout from "../../components/Layout";
import { FiPhoneCall, FiMail } from "react-icons/fi";
import AOS from "aos";

function Contact() {
  useEffect(() => {
    AOS.init({
      delay: 50,
      duration: 1500,
    });
  });
  return (
    <Layout
      title="Kontak | Didil's Group"
      heroText="Ada yang bisa kami bantu ?"
    >
      <Box>
        <Flex
          paddingY={"5%"}
          paddingX={"10%"}
          direction={{ base: "column", lg: "row" }}
          alignItems="center"
          justifyContent={{ base: "center", lg: "space-around" }}
          gap={5}
          data-aos="fade-up"
        >
          <Box
            width={{ base: "100%", lg: "30%" }}
            data-aos="fade-up"
            data-aos-delay="50"
          >
            <Text fontWeight={900} fontSize={45}>
              Didil's <br /> Group
            </Text>
            <Text fontWeight={300} fontSize={25}>
              Terima kasih sudah mampir! <br /> Jika kamu memiliki pertanyaan
              seputar Didil's Group hubungi kami melalui kontak di laman ini.
            </Text>
          </Box>

          <iframe
            width="325"
            height="280"
            frameBorder="0"
            src="https://www.bing.com/maps/embed?h=280&w=325&cp=-6.2217905567885055~106.80976867682011&lvl=11&typ=s&sty=r&src=SHELL&FORM=MBEDV8"
            scrolling="no"
            data-aos="fade-up"
            data-aos-delay="100"
          ></iframe>

          <Flex
            direction={"column"}
            gap={5}
            width={{ base: "100%", lg: "30%" }}
            data-aos="fade-up"
            data-aos-delay="150"
          >
            <Text fontWeight={900} fontSize={30}>
              Kantor Pusat Didil's Group
            </Text>
            <Text fontWeight={400} fontSize={22}>
              Alamat lengkap kantor kami akan segera hadir!
            </Text>
            <Box>
              <Flex gap={5}>
                <FiPhoneCall size={20} />
                <Text fontWeight={900}>+62 899-7409-517</Text>
              </Flex>
              <Flex gap={5}>
                <FiMail size={20} />
                <Text fontWeight={900}>didils.group@gmail.com</Text>
              </Flex>
            </Box>
          </Flex>
        </Flex>
      </Box>
    </Layout>
  );
}

export default Contact;
