import {
  Box,
  Flex,
  IconButton,
  Stack,
  useColorModeValue,
} from "@chakra-ui/react";
import { HamburgerIcon } from "@chakra-ui/icons";
import Logo from "../assets/images/logo-hor.png";
import Image from "next/image";
import Link from "next/link";

export default function Navbar({
  position = "absolute",
  bg = "transparent",
  color = "white",
  top = 10,
  article = false,
}) {
  function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
  }

  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }

  return (
    <Box zIndex={150} position={position} top={top} width={"100%"}>
      <Flex
        bg={useColorModeValue(bg, "gray.800")}
        color={useColorModeValue(color, "gray.600")}
        minH={"60px"}
        py={{ base: 2 }}
        px={{ base: 4 }}
        // borderBottom={1}
        // borderStyle={"solid"}
        // borderColor={useColorModeValue("gray.200", "gray.900")}
        align={"center"}
      >
        <Flex
          flex={{ base: 1, md: "auto" }}
          ml={{ base: -2 }}
          display={{ base: "flex", md: "none" }}
        >
          <IconButton
            onClick={openNav}
            icon={<HamburgerIcon w={5} h={5} />}
            variant={"ghost"}
            aria-label={"Toggle Navigation"}
          />
        </Flex>
        <Flex
          paddingX={{ base: "5%", lg: "10%" }}
          flex={{ base: 1 }}
          justify={{ base: "center", md: "space-between" }}
        >
          <Flex display={{ base: "none", md: "flex" }}>
            {article && (
              <Link href={"/"}>
                <Image
                  src={Logo}
                  width="200%"
                  height="50%"
                  alt="logo"
                  objectFit="contain"
                />
              </Link>
            )}
          </Flex>

          <Flex
            display={{ base: "none", md: "flex" }}
            ml={10}
            justifyContent="center"
          >
            <DesktopNav />
          </Flex>
        </Flex>
      </Flex>

      <div id="mySidenav" className="sidenav">
        <a className="closebtn" onClick={closeNav}>
          x
        </a>
        <Link href={"/#profil"}>
          <a onClick={closeNav}>Profil</a>
        </Link>
        <Link href={"/#layanan"}>
          <a onClick={closeNav}>Layanan</a>
        </Link>
        <Link href={"/contact"}>
          <a onClick={closeNav}>Kontak</a>
        </Link>
        <Link href={"/article"}>
          <a onClick={closeNav}>Artikel</a>
        </Link>
      </div>
    </Box>
  );
}

const DesktopNav = () => {
  const linkColor = useColorModeValue("gray.600", "gray.200");
  const linkHoverColor = useColorModeValue("gray.800", "white");
  const popoverContentBgColor = useColorModeValue("white", "gray.800");

  return (
    <Stack direction={"row"} spacing={4} alignSelf="center">
      {NAV_ITEMS.map((navItem) => (
        <Box key={navItem.label}>
          <Link
            p={2}
            href={navItem.href ?? "#"}
            fontSize={"sm"}
            fontWeight={500}
            color={linkColor}
            _hover={{
              textDecoration: "none",
              color: linkHoverColor,
            }}
          >
            {navItem.label}
          </Link>
        </Box>
      ))}
    </Stack>
  );
};

const NAV_ITEMS = [
  {
    label: "Profil",
    href: "/#profil",
  },
  {
    label: "Layanan",
    href: "/#layanan",
    children: [
      {
        label: "Website",
        subLabel: "Find your dream design job",
        href: "#",
      },
      {
        label: "Mobile App",
        subLabel: "An exclusive list for contract work",
        href: "#",
      },
      {
        label: "Design",
        subLabel: "An exclusive list for contract work",
        href: "#",
      },
    ],
  },
  {
    label: "Kontak",
    href: "/contact",
  },
  {
    label: "Artikel",
    href: "/article",
  },
];
