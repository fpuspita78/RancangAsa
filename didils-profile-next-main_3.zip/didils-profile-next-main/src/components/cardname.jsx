import { Container, Flex, Text } from "@chakra-ui/react";
import Image from "next/image";
import React, { useEffect } from "react";
import {
  FaFacebookSquare,
  FaInstagram,
  FaLinkedin,
  FaTwitter,
} from "react-icons/fa";
import Link from "next/link";
import AOS from "aos";

function Cardname({ src, name, title, linked = "#", ani = "fade-up" }) {
  useEffect(() => {
    AOS.init({
      delay: 50,
      duration: 2000,
    });
  });
  return (
    <>
      <Container
        w={"100%"}
        h={"100px%"}
        padding={5}
        pos="relative"
        data-aos={ani}
      >
        <Image
          src={src}
          layout="responsive"
          alt="icon"
          objectFit="contain"
          style={{ borderRadius: "10px" }}
        />
      </Container>
      <Flex
        direction={"column"}
        w={"100"}
        padding={5}
        justifyContent={"space-around"}
        data-aos={ani}
      >
        <Container>
          <Text fontFamily={"Oswald"} fontWeight={700} fontSize={30}>
            {name}
          </Text>
          <Text
            fontFamily={"Roboto"}
            fontWeight={700}
            textTransform="uppercase"
          >
            {title}
          </Text>
        </Container>
        <Container>
          <Flex gap={5}>
            <a href={linked} target="_blank" rel="noreferrer">
              <FaLinkedin size={20} />
            </a>
          </Flex>
        </Container>
      </Flex>
    </>
  );
}

export default Cardname;
