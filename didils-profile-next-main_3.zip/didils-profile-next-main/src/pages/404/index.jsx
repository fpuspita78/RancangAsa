import React from "react";
import Layout from "../../components/Layout";

function NotFound() {
  return (
    <div>
      <Layout title="Sorry we can't found you anything :(" />
    </div>
  );
}

export default NotFound;
