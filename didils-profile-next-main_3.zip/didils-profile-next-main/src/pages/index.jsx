/* eslint-disable react/no-unescaped-entities */
import Image from "next/image";
import styles from "../styles/Home.module.css";
import { Flex, Text, SimpleGrid, Container, Box } from "@chakra-ui/react";
import Logo from "../../public/logo.png";
import hero from "../assets/images/herolanding.jpg";
import about from "../assets/images/about.jpeg";
import vision from "../assets/images/vision.jpg";
import iPhone13 from "../assets/images/iPhone13.png";
import Learner from "../assets/images/learner.png";
import Tech from "../assets/images/tech.png";
import Accesibility from "../assets/images/read.png";
import fadil from "../assets/images/fadil.jpg";
import yana from "../assets/images/yana.jpg";
import shintya from "../assets/images/shintya.jpg";
import atikah from "../assets/images/atikah.jpg";
import nabila from "../assets/images/nabila.jpg";
import ari from "../assets/images/ari.jpg";
import website from "../assets/images/website.png";
import mobile from "../assets/images/mobile.png";
import design from "../assets/images/design.png";

import Cardname from "../components/cardname";

import { useEffect } from "react";
import AOS from "aos";
import Layout from "../components/Layout";

export default function Home() {
  useEffect(() => {
    AOS.init({
      delay: 50,
      duration: 1500,
    });
  });
  return (
    <Layout>
      <Flex direction={"column"} bgColor="#fff">
        {/* Hero start section */}

        {/* About us section */}
        <SimpleGrid
          columns={{ md: 1, lg: 3 }}
          paddingX="10%"
          paddingY={10}
          fontFamily={"Nunito Sans"}
          fontheight={400}
          gap={5}
          bgColor="#fff"
          id="profil"
        >
          <Flex direction={"column"} gap={5} data-aos="fade-up">
            <Flex w={"100%"} h={"100%"} position={"relative"}>
              <Image
                src={about}
                alt={"about"}
                w={"100%"}
                h={"100%"}
                style={{ borderRadius: "10px" }}
                objectFit="cover"
              />
            </Flex>
            <Flex w={"100%"} h={"100%"} direction="column" padding={5}>
              <Text
                fontFamily={"Oswald"}
                fontWeight={700}
                fontSize={30}
                mb="5"
                textAlign={"center"}
              >
                Tentang Kami
              </Text>
              <Text>
                Kami adalah startup teknologi yang sedang mengembangkan Platform
                kursus untuk mahasiswa yang kami beri nama Rancang Asa.
                Didirikan pada 1 November oleh beberapa mahasiswa dari berbagai
                universitas yang mengalami keluhan yang sama yaitu sulitnya
                mencari tutor untuk belajar tambahan. <br /> Didil’s Group
                meyakini bahwa teknologi merupakan kunci untuk mempermudah
                pekerjaan manusia, dengan teknologi pekerjaan dapat dilakukan
                lebih efektif dan efisien. Kami dapat membantu jika perusahaan
                anda memerlukan integrasi dengan sistem teknologi dan informasi,
                dengan begitu pekerjaan anda dapat diatas lebih mudah
              </Text>
            </Flex>
          </Flex>
          <Flex direction={"column"} gap={5} data-aos="fade-down">
            <Flex
              w={"100%"}
              h={"100%"}
              direction="column"
              padding={5}
              justifyContent={"center"}
            >
              <Text
                fontFamily={"Oswald"}
                fontWeight={700}
                fontSize={30}
                mb="5"
                textAlign={"center"}
              >
                Visi
              </Text>
              <Text
                borderLeft={"5px solid black"}
                fontStyle="italic"
                fontSize={18}
                paddingX={5}
                textAlign={"center"}
              >
                Memberikan dampak yang positif kepada masyarakat dalam segala
                aspek kehidupan
              </Text>
            </Flex>
            <Flex w={"100%"} h={"100%"}>
              <Image
                src={vision}
                alt={"about"}
                w={"100%"}
                h={"100%"}
                style={{ borderRadius: "10px" }}
                objectFit="cover"
              />
            </Flex>
          </Flex>
          <Flex direction={"column"} gap={5} data-aos="fade-up">
            <Flex position={"relative"} w={"100%"} height="100%">
              <Image
                src={iPhone13}
                alt={"about"}
                w={"100%"}
                h={"100%"}
                style={{ borderRadius: "10px" }}
              />
            </Flex>
            <Flex w={"100%"} h={"100%"} direction="column" padding={5}>
              <Text
                fontFamily={"Oswald"}
                fontWeight={700}
                fontSize={30}
                mb="5"
                textAlign={"center"}
              >
                Rancang Asa
              </Text>
              <Text>
                Rancang Asa merupakan platform kursus untuk mahasiswa yang
                sedang dikembangkan oleh Didil's Group. Menggunakan skema
                On-demand tutoring, Rancang Asa akan menjadi yang pertama di
                indonesia. Harapan kami dengan adanya Rancang Asa mahasiswa
                terbantu dalam proses belajar mereka
              </Text>
            </Flex>
          </Flex>
        </SimpleGrid>

        {/* Nilai Yang Kami Junjung */}
        <Flex
          bg={"rgba(233, 232, 233, 0.8)"}
          paddingX={"10%"}
          paddingY={10}
          direction="column"
        >
          <Text
            textAlign={"center"}
            fontFamily={"Oswald"}
            fontWeight={700}
            fontSize={36}
            mb={15}
            data-aos="fade-up"
          >
            Nilai Yang Kami Junjung
          </Text>
          <SimpleGrid columns={{ sm: 1, md: 3 }}>
            <Container
              w={"100"}
              padding={5}
              mt={10}
              data-aos="fade-up"
              data-aos-delay="50"
            >
              <Box>
                <Image src={Learner} width={50} height={50} alt="icon" />
              </Box>
              <Box fontFamily={"Oswald"} fontWeight={700} fontSize={30}>
                Continues Learner
              </Box>
              <Box>
                Kami meyakini belajar adalah kunci untuk selalu berinovasi
                hal-hal baru.
              </Box>
            </Container>
            <Container
              w={"100"}
              padding={5}
              mt={10}
              data-aos="fade-up"
              data-aos-delay="100"
              // data-aos-offset="200"
            >
              <Box>
                <Image src={Tech} width={50} height={50} alt="icon" />
              </Box>
              <Box fontFamily={"Oswald"} fontWeight={700} fontSize={30}>
                Technology
              </Box>
              <Box>
                Kami meyakini bahwa inovasi adalah kunci untuk mempermudah
                kehidupan manusia.
              </Box>
            </Container>
            <Container
              w={"100"}
              padding={5}
              mt={10}
              data-aos="fade-up"
              data-aos-delay="150"
            >
              <Box>
                <Image src={Accesibility} width={50} height={50} alt="icon" />
              </Box>
              <Box fontFamily={"Oswald"} fontWeight={700} fontSize={30}>
                Accesibility
              </Box>
              <Box>
                Kami ingin membantu orang-orang di seluruh dunia mendapatkan
                akses dengan teknologi yang kami buat.
              </Box>
            </Container>
          </SimpleGrid>
        </Flex>

        {/* Tim Kami */}
        <Flex paddingX={"10%"} paddingY={10} flexDirection="column">
          <Text
            textAlign={"center"}
            fontFamily={"Oswald"}
            fontWeight={700}
            fontSize={36}
            mb={15}
            data-aos="fade-up"
          >
            Tim Kami
          </Text>
          <SimpleGrid columns={{ sm: 1, md: 2, lg: 4 }}>
            <Cardname
              src={fadil}
              name={"Firdaus Fadilah"}
              title={"Chief Executive Officer"}
              linked="https://www.linkedin.com/in/firdaus-fadilah-5336521b4/"
            />
            <Cardname
              src={yana}
              name={"Yana Dian Nanda"}
              title={"Head of Operating"}
              linked="https://www.linkedin.com/in/yana-dian-nanda-83a724218/"
            />
            <Cardname
              src={shintya}
              name={"Shintya Utomo"}
              title={"Head of Product Development"}
              linked="https://www.linkedin.com/in/shintya-utomo-6b9226180/"
            />
            <Cardname
              src={atikah}
              name={"Atikah Vatin"}
              title={"Head of Marketing & Public Relation"}
              linked="https://www.linkedin.com/in/atikahvathine/"
            />
            <Cardname
              src={nabila}
              name={"Nabila Fitri. A"}
              title={"Head of Social Media"}
              linked="https://www.linkedin.com/in/nabilafitrialifia/"
            />
            <Cardname
              src={ari}
              name={"Ari Martua"}
              title={"Head of Human Capital"}
              linked="https://www.linkedin.com/in/ari-martua-ba1175175/"
            />
          </SimpleGrid>
        </Flex>
        {/* Our Services */}
        <Flex
          bg={"rgba(233, 232, 233, 0.8)"}
          paddingX={"10%"}
          paddingY={10}
          direction="column"
          id="layanan"
        >
          <Text
            textAlign={"center"}
            fontFamily={"Oswald"}
            fontWeight={700}
            fontSize={36}
            mb={15}
            data-aos="fade-up"
          >
            Layanan Kami
          </Text>
          <SimpleGrid columns={{ sm: 1, md: 3 }}>
            <Flex
              w={"100"}
              padding={5}
              mt={10}
              alignItems="center"
              direction={"column"}
              // justifyContent={"center"}
              data-aos="fade-up"
              data-aos-delay="50"
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  width: "100px",
                  height: "100px",
                  borderRadius: "100px",
                  background: "#478ac9",
                  justifyContent: "center",
                  // margin: "auto",
                }}
              >
                <Image src={website} width={50} height={50} alt="icon" />
              </div>
              <Text
                mt={5}
                mb={2}
                textAlign={"center"}
                fontFamily={"Oswald"}
                fontWeight={700}
                fontSize={30}
              >
                Responsive Website
              </Text>
              <Text textAlign={"center"}>
                Kami siap membantu anda dalam membangun web yang responsive.
                Nikmati kemudahan mengelola website sesuai keinginan Anda dengan
                performa hebat dan fitur lengkap. Jadikan web sebagai alat untuk
                memperluas bisnis anda!
              </Text>

              <Text mt={5} className={styles.learnmore}>
                Learn More
              </Text>
            </Flex>
            <Flex
              w={"100"}
              padding={5}
              mt={10}
              alignItems="center"
              textAlign={"center"}
              direction={"column"}
              // justifyContent={"center"}
              data-aos="fade-up"
              data-aos-delay="100"
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  width: "100px",
                  height: "100px",
                  borderRadius: "100px",
                  background: "#478ac9",
                  justifyContent: "center",
                  // margin: "auto",
                }}
              >
                <Image src={mobile} width={50} height={50} alt="icon" />
              </div>
              <Text
                mt={5}
                mb={2}
                textAlign={"center"}
                fontFamily={"Oswald"}
                fontWeight={700}
                fontSize={30}
              >
                Mobile Apps
              </Text>
              <Text textAlign={"center"}>
                Jasa pengembangan aplikasi seluler yang dapat disesuaikan dengan
                kebutuhan bisnis Anda, sehingga efektif dalam menyelesaikan
                pekerjaan. Kami akan memproses dengan cepat dan tepat, didukung
                oleh tim yang berpengalaman dan profesional.
              </Text>

              <Text mt={5} className={styles.learnmore}>
                Learn More
              </Text>
            </Flex>
            <Flex
              w={"100"}
              padding={5}
              mt={10}
              alignItems="center"
              // justifyContent={"center"}
              direction="column"
              data-aos="fade-up"
              data-aos-delay="150"
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  width: "100px",
                  height: "100px",
                  borderRadius: "100px",
                  background: "#478ac9",
                  justifyContent: "center",
                  // margin: "auto",
                }}
              >
                <Image src={design} width={50} height={50} alt="icon" />
              </div>
              <Text
                mt={5}
                mb={2}
                textAlign={"center"}
                fontFamily={"Oswald"}
                fontWeight={700}
                fontSize={30}
              >
                Product Design
              </Text>
              <Text textAlign={"center"}>
                Dalam membuat produk, design merupakan sesuatu yang penting.
                Design dapat membedakan dan memberikan keunggulan nyata atas
                pesaing. Kami dapat men-design produk fisik maupun digital anda
                agar dapat meningkatkan customer experience
              </Text>

              <Text mt={5} className={styles.learnmore}>
                Learn More
              </Text>
            </Flex>
          </SimpleGrid>
        </Flex>
      </Flex>
    </Layout>
  );
}
