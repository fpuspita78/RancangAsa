import "../styles/globals.css";
import { ChakraProvider } from "@chakra-ui/react";
import SSRProvider from "react-bootstrap/SSRProvider";
import AOS from "aos";
import "aos/dist/aos.css";

function MyApp({ Component, pageProps }) {
  return (
    <SSRProvider>
      <ChakraProvider>
        <Component {...pageProps} />
      </ChakraProvider>
    </SSRProvider>
  );
}

export default MyApp;
