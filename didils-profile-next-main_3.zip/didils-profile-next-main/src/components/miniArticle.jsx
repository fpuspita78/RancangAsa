import { Box, Container, Flex, Text } from "@chakra-ui/react";
import Image from "next/image";
import React, { useEffect } from "react";
import {
  FaFacebookSquare,
  FaInstagram,
  FaLinkedin,
  FaTwitter,
} from "react-icons/fa";
import Link from "next/link";
import AOS from "aos";
import { IoIosCalendar } from "react-icons/io";

function MiniArticle({ imageSrc, title, ani = "fade-up" }) {
  useEffect(() => {
    AOS.init({
      delay: 50,
      duration: 2000,
    });
  });
  return (
    <Flex
      columnGap={10}
      flexWrap={"wrap"}
      borderRadius={"20px"}
      bg="white"
      padding={"2%"}
    >
      <Box
        w={{ base: "100%", md: "25rem" }}
        h={"10rem"}
        // height={"fit-content"}
        padding={5}
        pos="relative"
        data-aos={ani}
      >
        <Image
          src={imageSrc}
          layout="fill"
          alt="icon"
          objectFit="contain"
          style={{ borderRadius: "10px" }}
        />
      </Box>
      <Flex
        direction={"column"}
        // w={{ base: "100%", md: "40rem" }}
        padding={5}
        justifyContent={"space-around"}
        data-aos={ani}
      >
        <Container>
          <Text fontFamily={"Oswald"} fontWeight={700} fontSize={30}>
            {title}
          </Text>
        </Container>
        <Container>
          <Flex gap={5} mt={5}>
            <IoIosCalendar size={20} color="#478ac9" />
            <Text color={"gray.500"}>{new Date().toDateString()}</Text>
          </Flex>
          <Text fontSize={20} color="#478ac9" mt={5}>
            <Link href={`/article/${title}`}>Read Article</Link>
          </Text>
        </Container>
      </Flex>
    </Flex>
  );
}

export default MiniArticle;
